import emManage.*;
import entity.*;
import gui.*;
import reg.*;
import IInter.*;

public class Main {

    public static void main(String[] args) {

        Cover ob = new Cover();
        ob.setVisible(true);

    }
}
